#include "sdkaddon.h"
#include <node.h>

#include <sstream>
#include <string>
#include <cstring>
#include <memory>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>

#include "tools.h"
#include "sdk2_1.h"
#include "json/json.h"
#include <libRPDCard.h>
#include <libRFMCard.h>
#include <libGenerationsEpson.h> 
#include "cashin.h"
#include "cashin_nv9.h"
#include "cash_in_v77e.h"

#if defined(__linux__)
#include <unistd.h>
//dlopen dlsym dlclose
//#include <dlfcn.h> 
#else
#include <windows.h>
#endif

//#include "ICTcoinin1.h"

//#include <boost/thread.hpp>
//#include <boost/date_time/posix_time/posix_time.hpp>

int g_epson_type=1;
bool g_epson_init=false;
map<string, ThreadData*> g_map_DevThreadData; //init new\end del
Icash_in *g_cashin = NULL;

//////////////////////////////////////////////////////////////////////////////////////////////////
void Add(const FunctionCallbackInfo<Value>& args) 
{
  Isolate* isolate = args.GetIsolate();
  //Local<Context> context = isolate->GetCurrentContext(); 

  if (args.Length() < 2) {
	//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
	return;
  }

  if (!args[0]->IsNumber() || !args[1]->IsNumber()) {
	//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
	return;
  }

  double value = args[0].As<Number>()->Value() + args[1].As<Number>()->Value();
  Local<Number> num = Number::New(isolate, value);

  char str[100] = {0};
  sdk::Test(str); //call dll/so
  cout<<str<<endl;
	
  args.GetReturnValue().Set(num);
}
static void RunCallback(const FunctionCallbackInfo<Value>& args) {
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();  
  
  Local<Function> cb = Local<Function>::Cast(args[0]); 
  
  const unsigned argc = 1;
  Local<Value> argv[argc] = {
	  String::NewFromUtf8(isolate, "hello world!!!", NewStringType::kNormal).ToLocalChecked() 
  };
  cb->Call(context, Null(isolate), argc, argv).ToLocalChecked();
}
static void RunCallback2(const FunctionCallbackInfo<Value>& args) {
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();  
  
  Local<Function> cb = Local<Function>::Cast(args[0]); //坑，离开区域会爆
  
  v8::String::Utf8Value buf(isolate, args[1]);
  stringstream ss;
  ss << *buf;
  cout << ss.str()<<endl;
		  
  const unsigned argc = 1;
  Local<Value> argv[argc] = {
	  String::NewFromUtf8(isolate, "hello yyb!!!", NewStringType::kNormal).ToLocalChecked() 
  };
  cb->Call(context, Null(isolate), argc, argv).ToLocalChecked();
}


void sendCallbackFunc(uv_async_t *handle) 
{
    HandleScope handle_scope(Isolate::GetCurrent()); //这里是必须的,调用js函数需要一个handle scope
    DevParams*  devParam = (DevParams *) handle->data;
	string devName = devParam->deviceName;
	//cout<<"sendCallbackFunc " << devName << " start"<<endl;
	
	//if(devParam->deviceName == "icCard" || devParam->deviceName == "cashin")
	{
		int argc = 1;
		Local<Value> argv[1] = {String::NewFromUtf8(devParam->isolate, devParam->resultjs.c_str())};
		Local<Function>::New(devParam->isolate, devParam->oncallback)->Call(devParam->isolate->GetCurrentContext(), Null(devParam->isolate), argc, argv); 		
	}
	
	//cout<<"sendCallbackFunc " << devName << " end"<<endl;
}


void cashinhandler(void *extra, int cash_in_event_code, const char *event_code_description, int money, int len)
{	
	if(extra == NULL)
	{
		//cout<<"cashinhandler,extra is NULL"<<endl;
		return ;
	}
	DevParams *data = (DevParams*) extra;
	
	if(data->subDev == 1){
		if(cash_in_event_code == 0xE8)
		{
			data->enable = false;
		}	
	}else if(data->subDev == 2){
		if(cash_in_event_code == 0x3E)
			data->enable = true;
		else if(cash_in_event_code == 0x5E)
			data->enable = false;
	}	
	
	string str = "";
	switch (len){
	case 1:
		str = "人民币！";
		break;
	case 2:
		str = "美元";
		break;
	case 3:
		str = "墨西哥比索！";
		break;
	case 4:
		str = "设备支持一种的情况(默认币种)";
		break;
	case 0:
	default:
		str = "未知币种";
		break;
	}
	Json::Value root;
	Json::FastWriter writer;  
	root["eventcode"] = cash_in_event_code;
	root["eventcodeDescription"] = event_code_description;
	root["money"] = money;
	root["currency"] = str;
	data->resultjs = writer.write(root);
	cout<<data->resultjs<<endl;

	uv_async_send(data->callbackSendReq);	
}

void close_cb(uv_handle_t* handle)
{
	//cout<<"close_cb start and end"<<endl;
}
void freeGoThreadData(DevParams* data) 
{
	//cout<<"freeGoThreadData start"<<endl;
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find(data->deviceName);
	if ( it != g_map_DevThreadData.end() ){
		ThreadData* td = it->second;
		if(td != 0)
		{
			if(td->req != 0){
				delete td->req;
				td->req = 0; 
			}
			if(td->param != 0){
				if(td->param->callbackSendReq != 0){
					delete td->param->callbackSendReq;
					td->param->callbackSendReq = 0;
				}
				delete td->param;
				td->param = 0;
			}	
			delete td;
			td = 0;
		}
	}
	//cout<<"freeGoThreadData end"<<endl;
}
/*//子库里线程的回调用，暂无用 
void goCallback(void *extra, char *arg)
{	
	DevParams *data = (DevParams*) extra;
	uv_async_send(data->callbackSendReq);  
}*/
void callGoThread(uv_work_t* req)
{
    	// 从uv_work_t的结构体中获取我们定义的入参结构
    	auto* devParam = (DevParams*) req->data;
	devParam->status = 1;
	string devName = devParam->deviceName;
	//cout<<endl<<"callGoThread "<< devName << " start"<<endl;
 	char buf[100] = {0}; 
	unsigned char m_recvdata[4096] = {0};

	if(devParam->deviceName == "icCard")
	{
		while(!devParam->exit)
		{
			if(devParam->enable)
			{
				if(devParam->subDev == 1){
					cout<<"icCard enable"<<endl;
					bool bRet; int nRet;
					memset(buf, 0x00, sizeof(buf));
					bRet = IRPD_Request(1, buf);
					cout<<"IRPD_Request end"<<endl;
					if (bRet){		
						memset(buf, 0x00, sizeof(buf));
						bRet = IRPD_Anticoll(buf);
						if(bRet){
							nRet = IRPD_Select(buf);
							if (nRet >= 0){
								bRet = IRPD_VerifyPassWord(1, devParam->blocknum);
								if (bRet){
									string o_data = IRPD_ReadBlock(devParam->blocknum);
									if (o_data != ""){	
										IRPD_Beep(10);
										#if defined(__linux__)
										sleep(1); 
										#else
										Sleep(1000);
										#endif

										Json::Value root;
										Json::FastWriter writer;  
										root["cardno"] = o_data;
										devParam->resultjs = writer.write(root);
										uv_async_send(devParam->callbackSendReq); 									
									}
								}
							}
						}
					}
				}
				else if(devParam->subDev == 0)
				{
					cout<<"icCard enable"<<endl;
					bool bRet; char bufdata[33] = {0};
					bRet = IRFM_operateAntenna(true);
					if(bRet){
						string res = IRFM_searchCard(0);
						if(res != "")
						{
							memset(buf, 0x00, sizeof(buf));
							memcpy(buf, res.data(), res.size());
							string serial = RFM_preventConflict();
							if(serial != "")
							{
								string str=RFM_selectCard(serial);
								if(str != "")
								{
									bRet = RFM_verifyPassWord(1, devParam->blocknum);
									if(bRet)
									{
										string o_data=RFM_readBlock(devParam->blocknum);
										if(o_data != "")
										{
											memset(bufdata, 0x00, sizeof(bufdata)); 
											memcpy(bufdata, o_data.c_str(), MINFUNCTION(o_data.length(), 32));
											RFM_beer(2);
											RFM_beer(1);
											Json::Value root;
											Json::FastWriter writer;  
											root["cardno"] = bufdata;
											devParam->resultjs = writer.write(root);
											uv_async_send(devParam->callbackSendReq);

											#if defined(__linux__)
											usleep(100); 
											#else
											Sleep(100);
											#endif
										}
									}
								}
							}
						}
					}
				}	
			} //enable
			else
			{
				cout<<"icCard disable"<<endl;
				#if defined(__linux__)
				sleep(1); 
				#else
				Sleep(1000);
				#endif
			} //disable			
		} //exit

		if(devParam->subDev == 1){
			IRPD_cleanUp();
		}
		else if(devParam->subDev == 0){
			IRFM_cleanUp();
		}
	} //icCard
	else if(devParam->deviceName == "cashin")
	{
		if(devParam->subDev == 1){ //itl nv9
			int count = 0;
			while(!devParam->exit)
			{
				if(devParam->enable)
				{
					if(count > 100)
					{
						g_cashin->cash_in_sync1(true);
						count = 0;
					}
					
					g_cashin->cash_in_poll1();			
				} //enable
				else
				{
				} //disable
				
				#if defined(__linux__)
				usleep(100); 
				#else
				Sleep(100);
				#endif
			} //exit
			
			if(devParam->enable){
				g_cashin->cash_in_disable();
			}
			g_cashin->cash_in_closeport();
		}else if(devParam->subDev == 2){ //ict v77e
			#if defined(__linux__)
			sleep(3); 
			#else
			Sleep(3000);
			#endif
			int m_nNeedLen = 1;
			int m_tRecvLen = 0;
			int m_tRecvLenLst = 0; 
			memset(m_recvdata, 0x00, sizeof(m_recvdata));
			int m_sendStatus = 1;
			
			while(!devParam->exit)
			{
				g_cashin->cash_in_poll2(&m_nNeedLen, &m_tRecvLen, &m_tRecvLenLst, m_recvdata, &m_sendStatus);							
			}
			
			if(devParam->enable){
				g_cashin->cash_in_disable();
			}
			g_cashin->cash_in_closeport();
		}else{
			return;
		}
	} //cashin
	//cout<<endl<<"callGoThread "<< devName << " end"<<endl;
}
void afterGoTread (uv_work_t* req, int status) {
    cout<<endl<<"afterGoTread start"<<endl;
    auto* devParam = (DevParams*) req->data;
    char buf[1024] = {0};
    sprintf(buf, "afterGoTread deviceName:%s", devParam->deviceName.c_str());    
    cout<<buf<<endl;
    devParam->status = 2;
    HandleScope handle_scope(Isolate::GetCurrent()); //这里是必须的,调用js函数需要一个handle scope
    uv_close((uv_handle_t*) devParam->callbackSendReq, close_cb); //3.删除通知js的事件
    freeGoThreadData(devParam); //释放内存
    cout<<endl<<"afterGoTread end"<<endl;
}

static void HardWareEnd(const FunctionCallbackInfo<Value>& args) {
	cout<<"HardWareEnd"<<endl;
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	//exit thread
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("icCard");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		if(td != NULL)
		{
			td->param->exit = true;
		}
	}
	//exit thread by delete object
	if(g_cashin != NULL){
		delete g_cashin;
		g_cashin = NULL; 
	}
	
	if(g_epson_init){
		cout<<"lib_printer_end"<<endl;
		lib_printer_end();
	}
	
	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	root["result_code"] = 0;
	root["result_msg"] = "success";
	json_out = write.write(root);
	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}

void HardWareInit(const FunctionCallbackInfo<Value>& args) {
  cout<<"HardWareInit"<<endl;
  Isolate* isolate = args.GetIsolate();
  Local<Context> context = isolate->GetCurrentContext();  

  if (args.Length() < 9) {
	//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
	return;
  }
  
  //out json  
  Json::Value outRoot;
  Json::Value outData;
  Json::Value outdevcoin;
  Json::Value outdevcashin;
  Json::Value outdevcashout;
  Json::Value outdevprinter;
  Json::Value outdevunion;
  Json::Value outdeviCcard;
  Json::FastWriter outWriter;  
  string outJson;
  outRoot["result_code"] = 0;
  outRoot["result_msg"] = "success";

  //v8::String::Utf8Value execPath(args[0]->ToString());  
  Local<Value> v = args[0]; 
  v8::String::Utf8Value execPath(isolate, v); 
  
  stringstream ss;
  ss << *execPath;
  //cout<<"execPath:"<<ss.str().c_str()<<endl;
  
  stringstream ss2;
  v8::String::Utf8Value callbackJSFile(isolate, args[1]); 
  ss2 << *callbackJSFile;
  //cout<<"callbackJSFile:"<<ss2.str().c_str()<<endl;

  //v8插件
  //HardWareApp::start(isolate, context, ss.str().c_str(), "", ss2.str().c_str());
  
  cout<<"111"<<endl;
  //in json
  v8::String::Utf8Value inijs(isolate, args[2]); 
  Json::Reader reader;
  Json::Value  root;
  Json::Value  jsonVal_coin;
  int m_coin_type=-1;
  int m_national_cny=-1;
  char m_serial_coin_in[32] = {0};
  int m_include_coin_out_half = -1;
  int m_include_coin_out_one = -1;
  int m_box_coin_out_one = -1;
  int m_serial_coin_out_half = -1;
  int m_serial_coin_out_one = -1;
  Json::Value  jsonVal_cashin;
  int m_cash_in_type = -1;
  char m_serial_cash_in[32] = {0};
  int m_cash_accept = -1;
  int m_cash_model = -1;
  Json::Value  jsonVal_cashout;
  int m_cash_out_type = -1;
  char m_serial_cash_out[32] = {0};
  int m_cashbox_num = -1;
  int m_cashbox0_money_type = -1;
  int m_cashbox1_money_type = -1;
  int m_cashbox2_money_type = -1;
  int m_cashbox3_money_type = -1;
  int m_cashbox4_money_type = -1;
  int m_cashbox5_money_type = -1;
  int m_cashbox0_ID = -1;
  int m_cashbox1_ID = -1;
  int m_cashbox2_ID = -1;
  int m_cashbox3_ID = -1;
  int m_cashbox4_ID = -1;
  int m_cashbox5_ID = -1;
  int m_country_currentcy = -1;
  Json::Value  jsonVal_printer;
  int m_printer_type = -1;
  char m_serial_printer[32] = {0};
  int m_baudrate_printer = -1;
  Json::Value  jsonVal_union;
  int m_union_type = -1;
  char m_serial_union[32] = {0};
  int m_union_zhongyu = -1;
  int m_union_BsweepC = -1;
  Json::Value  jsonVal_iccard;
  int m_iCcard_type = -1;
  char m_serial_iccard[32] = {0};
  Json::Value  jsonVal_system;
  string m_authorization_code = "";
  if(reader.parse(*inijs, root))
  {
	  cout<<"222"<<endl;
	  jsonVal_system = root["System"];
	  m_authorization_code = jsonVal_system["authorization_code"].asString();
	  cout<<"333"<<endl;
	  //coin
	  jsonVal_coin = root["CoinDevType"];
	  m_coin_type = atoi(jsonVal_coin["coin_type"].asString().c_str());
	  m_national_cny = atoi(jsonVal_coin["national_cny"].asString().c_str());
	  if(m_coin_type != -1){
	  }else{
		  outRoot["result_code"] = -1;
		  outRoot["result_msg"] = "硬件初始化失败！";
		  outdevcoin["dev_name"] = "coin";
		  outdevcoin["init_result"] = false;
		  outdevcoin["init_msg"] = "不包含硬币器模块"; 
		  outData.append(outdevcoin);
	  }
	  cout<<"444"<<endl;
	  //printer
	  jsonVal_printer = root["PrinterDevType"];
	  m_printer_type = atoi(jsonVal_printer["printer_type"].asString().c_str()); //3一代 4二代	 
	  if(m_printer_type == 3)
		  g_epson_type = 1;
	  else if(m_printer_type == 4)
		  g_epson_type = 2;
      strcpy(m_serial_printer, jsonVal_printer["serial_printer"].asString().c_str());
      m_baudrate_printer = atoi(jsonVal_printer["baudrate_printer"].asString().c_str());
	  if(m_printer_type != -1){
		  g_epson_init = lib_printer_init(0, m_serial_printer, m_baudrate_printer);
		  if (!g_epson_init)
		  {
			  outRoot["result_code"] = -1;
			  outRoot["result_msg"] = "硬件初始化失败！";
			  outdevprinter["dev_name"] = "printer";
			  outdevprinter["init_result"] = false;
			  outdevprinter["init_msg"] = "打印机初始化失败"; 
			  outData.append(outdevprinter);
		  }
		  else
		  {
			  outdevprinter["dev_name"] = "printer";
			  outdevprinter["init_result"] = true;
			  outdevprinter["init_msg"] = "打印机初始化成功";
			  outData.append(outdevprinter);
		  }
	  }else{
		  outRoot["result_code"] = -1;
		  outRoot["result_msg"] = "硬件初始化失败！";
		  outdevprinter["dev_name"] = "printer";
		  outdevprinter["init_result"] = false;
		  outdevprinter["init_msg"] = "不包含打印机模块"; 
		  outData.append(outdevprinter);
	  }
	  cout<<"555"<<endl;
	  //iccard
	  jsonVal_iccard = root["ICcardDevType"];
	  m_iCcard_type = atoi(jsonVal_iccard["iCcard_type"].asString().c_str());
	  strcpy(m_serial_iccard, jsonVal_iccard["serial_iccard"].asString().c_str());	
	  cout<<"m_serial_iccard"<<m_serial_iccard<<endl;
	  unsigned char *keya_[16]; unsigned char *keyb_[16];	
	  if(m_iCcard_type == 1){
		  if(IRPD_init(0, m_serial_iccard, keya_, keyb_, 0) == 0)
		  {
			 outdeviCcard["dev_name"] = "icCard";
			 outdeviCcard["init_result"] = true;
			 outdeviCcard["init_msg"] = "IC读卡器初始化成功";
			 outData.append(outdeviCcard);
		  }
		  else
		  {
			 outRoot["result_code"] = -1;
			 outRoot["result_msg"] = "硬件初始化失败！";
			 outdeviCcard["dev_name"] = "icCard";
			 outdeviCcard["init_result"] = false;
			 outdeviCcard["init_msg"] = "IC读卡器初始化失败"; 
			 outData.append(outdeviCcard);
			 IRPD_cleanUp();
		  }		  
	  }else if(m_iCcard_type == 0){
		if(IRFM_init(0, m_serial_iccard, keya_, keyb_, 0) == 0)
		{
			 outdeviCcard["dev_name"] = "icCard";
			 outdeviCcard["init_result"] = true;
			 outdeviCcard["init_msg"] = "IC读卡器初始化成功";
			 outData.append(outdeviCcard);
		}
		else
		{
			 outRoot["result_code"] = -1;
			 outRoot["result_msg"] = "硬件初始化失败！";
			 outdeviCcard["dev_name"] = "icCard";
			 outdeviCcard["init_result"] = false;
			 outdeviCcard["init_msg"] = "IC读卡器初始化失败"; 
			 outData.append(outdeviCcard);
			 IRFM_cleanUp();
		}
	  }else{
		outRoot["result_code"] = -1;
	   	outRoot["result_msg"] = "硬件初始化失败！";
	   	outdeviCcard["dev_name"] = "icCard";
	   	outdeviCcard["init_result"] = false;
	   	outdeviCcard["init_msg"] = "不包含读卡器模块"; 
	   	outData.append(outdeviCcard);			   
	  }
	  cout<<"666"<<endl;
	  //cashin 
	  jsonVal_cashin = root["CashInDevType"];
	  m_cash_in_type = atoi(jsonVal_cashin["cash_in_type"].asString().c_str());
	  cout<<"m_cash_in_type=" << m_cash_in_type <<endl;
	  strcpy(m_serial_cash_in, jsonVal_cashin["serial_cash_in"].asString().c_str());
	  m_cash_accept = atoi(jsonVal_cashin["cash_accept"].asString().c_str());
	  m_cash_model = atoi(jsonVal_cashin["cash_model"].asString().c_str());
	  cout<<"m_cash_model="<<m_cash_model<<endl;	  
	  bool toInitFlag = false;
	  if(m_cash_in_type != -1)
	  {			  
		  switch(m_cash_in_type)
		  {
			  case 1:
			  cout<<"6661"<<endl;
			  g_cashin = new cash_in_junpeng(cashinhandler, m_serial_cash_in, m_cash_accept);
			  toInitFlag = true;			  
			  break;
		  
			  case 2:
			  cout<<"6662"<<endl;
			  g_cashin = new cash_in_v77e(cashinhandler, m_serial_cash_in, m_cash_accept);
			  toInitFlag = true;
			  break;
			  
			  default:
			  cout<<"6663"<<endl;
			  outRoot["result_code"] = -1;
			  outRoot["result_msg"] = "硬件初始化失败！";
			  outdevcashin["dev_name"] = "cashin";
			  outdevcashin["init_result"] = false;
			  outdevcashin["init_msg"] = "未知的纸币接收器"; 
			  outData.append(outdevcashin);
			  break;
		  }
	  }else{
		  cout<<"6664"<<endl;
		  outRoot["result_code"] = -1;
		  outRoot["result_msg"] = "硬件初始化失败！";
		  outdevcashin["dev_name"] = "cashin";
		  outdevcashin["init_result"] = false;
		  outdevcashin["init_msg"] = "不包含纸币接收器模块"; 
		  outData.append(outdevcashin);
	  }	  
	  if(toInitFlag)
	  {
		  cout<<"toInitFlag"<<endl;
		  if(g_cashin == NULL)
		  {
			  outRoot["result_code"] = -18;
			  outRoot["result_msg"] = "纸币接收模块初始化失败(对象实例化失败)";
			  outdevcashin["dev_name"] = "cashin";
			  outdevcashin["init_result"] = false;
			  outdevcashin["init_msg"] = "纸币接收器实例化失败"; 
			  outData.append(outdevcashin);
		  }
		  else
		  {
			  int cashin_init_res = g_cashin->cash_in_init();
			  if(cashin_init_res != 0)
			  {
				  //cout<<"cashin_init_res="<<cashin_init_res<<endl;
				  outdevcashin["dev_name"] = "cashin";
				  outdevcashin["init_result"] = true;
				  outdevcashin["init_msg"] = "纸币接收器初始化成功"; 
				  outData.append(outdevcashin);
			  }
			  else
			  {
				  outRoot["result_code"] = -1;
				  outRoot["result_msg"] = "硬件初始化失败！";
				  outdevcashin["dev_name"] = "cashin";
				  outdevcashin["init_result"] = false;
				  outdevcashin["init_msg"] = "纸币接收初始化失败！"; 
				  outData.append(outdevcashin);
			  }
		  }
	  }
  }
  
  v8::String::Utf8Value logpath(isolate, args[3]); 
  stringstream ss4;
  ss4 << *logpath;
  cout<<"logpath:"<<ss4.str().c_str()<<endl;
  
  v8::String::Utf8Value serverdatetime(isolate, args[4]); 
  stringstream ss5;
  ss5 << *serverdatetime;
  cout<<"serverdatetime:"<<ss5.str().c_str()<<endl;
 
  //创建线程
  cout<<"777"<<endl;
  //cout<<outdevcashin["init_result"].asString()<<endl;
  if(outdevcashin["init_result"].asString() == "true")
  {
	  ThreadData* cashInthreadData = new ThreadData;
	  cashInthreadData->inijs = *inijs;
	  cashInthreadData->logpath = *logpath;
	  cashInthreadData->serverdatetime = *serverdatetime;
	  
	  cashInthreadData->deviceName = "cashin";
	  uv_work_t* cashinreq = new uv_work_t();
	  cashInthreadData->req = cashinreq;
	  DevParams* cashinParam = new DevParams;
	  cashinParam->isolate = isolate;
	  cashinParam->oncallback.Reset(isolate, Local<Function>::Cast(args[8]));
	  cashinParam->deviceName = "cashin";
	  cashinParam->subDev = m_cash_in_type; //
	  uv_async_t *cashincallbackSendReq = new uv_async_t();
	  cashinParam->callbackSendReq = cashincallbackSendReq;
	  cashinParam->exit = false;
	  cashinParam->initFlag = true;
	  cashinParam->enable = false;
	  cashinParam->status = 0;
	  cashinParam->resultjs.clear();
	  cashInthreadData->param = cashinParam;
	  cashInthreadData->param->callbackSendReq->data = (void*)cashInthreadData->param;
	  g_map_DevThreadData["cashin"] = cashInthreadData;
	  
	  g_cashin->setParam(cashInthreadData->param);
	  
	  uv_async_init(uv_default_loop(), cashInthreadData->param->callbackSendReq, sendCallbackFunc);
	  
	  cashInthreadData->req->data = cashInthreadData->param;
	  uv_queue_work(uv_default_loop(), cashInthreadData->req, callGoThread, afterGoTread);
  }
  cout<<"888"<<endl;
  if(outdeviCcard["init_result"].asString() == "true")
  {
	  //1.对参数格式化
	  cout<<"new ThreadData"<<endl;
	  ThreadData* icCardthreadData = new ThreadData;
	  icCardthreadData->inijs = *inijs;
	  icCardthreadData->logpath = *logpath;
	  icCardthreadData->serverdatetime = *serverdatetime;
	  
	  icCardthreadData->deviceName = "icCard";
	  cout<<"new uv_work_t"<<endl;
	  uv_work_t* icCardreq = new uv_work_t(); //多线程uv
	  icCardthreadData->req = icCardreq; 
	  cout<<"new DevParams"<<endl;
	  DevParams* icCardParam = new DevParams;
	  icCardParam->isolate = isolate;
	  icCardParam->oncallback.Reset(isolate, Local<Function>::Cast(args[7]));
	  icCardParam->deviceName = "icCard";
	  icCardParam->subDev = m_iCcard_type;
	  cout<<"new DevParams uv_async_t"<<endl;
	  uv_async_t *icCardcallbackSendReq = new uv_async_t(); //异步uv
	  icCardParam->callbackSendReq = icCardcallbackSendReq; 
	  icCardParam->exit = false;
	  icCardParam->initFlag = true;
	  icCardParam->enable = false;
	  icCardParam->status = 0;
	  icCardParam->resultjs.clear();
	  icCardthreadData->param = icCardParam; 
	  icCardthreadData->param->callbackSendReq->data = (void*)icCardthreadData->param; //
	  g_map_DevThreadData["icCard"] = icCardthreadData;
		
	  //2.注册异步uv事件（暂时没用到，因为子库里线程没有到达预计的效果）
	  //cout<<"uv_async_init"<<endl;  
	  uv_async_init(uv_default_loop(), icCardthreadData->param->callbackSendReq, sendCallbackFunc); 
	  
	  //3.实现多线程uv
	  icCardthreadData->req->data = icCardthreadData->param; //
	  //cout<<"uv_queue_work"<<endl;
	  uv_queue_work(uv_default_loop(), icCardthreadData->req, callGoThread, afterGoTread);    
  }
  //cout<<"ictcoinin_init start"<<endl;
  //int ret = ictcoinin_init("COM5", 1);
  //cout<<"ictcoinin_init ret=" << ret << " end"<<endl;
  
  outRoot["data"] = outData;
  outJson = outWriter.write(outRoot);

  //Local<Number> num = Number::New(isolate, ret);
  //args.GetReturnValue().Set(num);
  auto result = v8::String::NewFromUtf8(isolate, outJson.c_str(), v8::NewStringType::kNormal, (int)outJson.size()).ToLocalChecked();
  args.GetReturnValue().Set(result);
}

/*static void CoinInEnable(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//threadData->enable = true;
	info = "enable succ";//hd_coin_in_enable();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinInDisable(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_coin_in_disable();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinOutCheck(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_coin_out_check();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinOutReset(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_coin_out_reset();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinOutPayout(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int money = args[0].As<Number>()->Value();

	string info = "";
	//info = hd_coin_out_payout(money);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinOutPayoutByNum(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 2) {
		//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber() || !args[1]->IsNumber()) {
		//isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int one = args[0].As<Number>()->Value();
	int half = args[1].As<Number>()->Value();

	string info = "";
	//info = hd_coin_out_payout_by_num(one, half);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinOutPayoutByNum3(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 3) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber() || !args[1]->IsNumber() || !args[2]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int five = args[0].As<Number>()->Value();
	int ten = args[1].As<Number>()->Value();
	int fifty = args[2].As<Number>()->Value();

	string info = "";
	//info = hd_coin_out_payout_by_num3(five, ten, fifty);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void CoinOutClear(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_coin_out_clear();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void GoodsOut(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int column_num = args[0].As<Number>()->Value();

	string info = "";
	//info = hd_goods_out(column_num);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void GoodsTest(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int column_num = args[0].As<Number>()->Value();

	string info = "";
	//info = hd_goods_test(column_num);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
static void PrinterEcho(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 5) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int flag = args[0].As<Number>()->Value();
	v8::String::Utf8Value content(isolate, args[1]); 
	stringstream ss;
	ss << *content;
	int size = args[2].As<Number>()->Value();
	int bold1 = args[3].As<Number>()->Value(); 
	int align = args[4].As<Number>()->Value();
	
	string info = "";
	Json::Value root;
	string str2 = "";
	string str = "";
	int ret = 0;
	switch(flag)
	{
		case 1:
			str = "打印文本";
			ret = lib_printer_println((char*)ss.str().c_str());
			break;
		case 2:
			str = "打印条码";
			ret = lib_printer_printBarcode(g_epson_type,120,2,2,1,(char*)ss.str().c_str());
			break;
		case 3: 
			str = "小票打印机打印二维码";
			ret = lib_printer_printQr(g_epson_type, (char*)ss.str().c_str());
			break;
	}
	
	if(ret == 0){
		str2 = str += "成功";
		root["result_code"] = 0;
		root["result_msg"] = "success";
	}else{
		str2 = str + "失败";
		root["result_code"] = -15;
		root["result_msg"] = str2;
	}
	root["printer_error_code"] =ret;
	//root["printer_error_msg"] = get_status_str(ret);
	
	Json::FastWriter outWriter;  
    string outJson = outWriter.write(root);

	//outJson = hd_printer_echo(flag, ss.str().c_str(), size, bold1, align);
	auto result = v8::String::NewFromUtf8(isolate, outJson.c_str(), v8::NewStringType::kNormal, (int)outJson.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
/*static void PrinterEcho12(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 5) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int type = args[0].As<Number>()->Value();
	v8::String::Utf8Value content(isolate, args[1]); 
	stringstream ss;
	ss << *content;
	int size = args[2].As<Number>()->Value();
	int bold2 = args[3].As<Number>()->Value(); 
	int bCut = args[4].As<Number>()->Value(); 
	
	string info = "";
	//info = hd_printer_echo12(type, ss.str().c_str(), size, bold2, bCut);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void PrinterEcho2(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 5) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int type = args[0].As<Number>()->Value();
	v8::String::Utf8Value content(isolate, args[1]); 
	stringstream ss;
	ss << *content;
	int size = args[2].As<Number>()->Value();
	int bold3 = args[3].As<Number>()->Value(); 
	int bCut = args[4].As<Number>()->Value(); 
	
	string info = "";
	//info = hd_printer_echo2(type, (char*)ss.str().c_str(), size, bold3, bCut);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void PrinterEcho22(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 10) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	//int type = args[0].As<Number>()->Value();
	Local<Number> ltype = Local<Number>::Cast(args[0]);
	int type = ltype->Value();
	int size = args[2].As<Number>()->Value();
	int lmargin = args[4].As<Number>()->Value();
	int scale = args[5].As<Number>()->Value();
	int align = args[6].As<Number>()->Value();
	long witdth = args[7].As<Number>()->Value();
	long height = args[8].As<Number>()->Value();
	int bold4 = args[3].As<Number>()->Value(); 
	int bCut = args[9].As<Number>()->Value(); 
	v8::String::Utf8Value content(isolate, args[1]); 
	stringstream ss;
	ss << *content;
	
	string info = "";
	//info = hd_printer_echo22(type, (char*)ss.str().c_str(), size, bold4, lmargin, scale, align, witdth, height, bCut);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
static void PrinterCut(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	info = lib_printer_cut(1); //1全切 2半切 3进纸半切 4半切
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
/*static void PrinterCheckStatus(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_printer_check_status();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void PrinterFastPic(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 3) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int type = args[0].As<Number>()->Value();
	int bmp_index = args[1].As<Number>()->Value(); //char
	int size = args[2].As<Number>()->Value();
	
	string info = "";	
	//info = hd_printer_fast_pic(type, bmp_index, size);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
static void Cashinenable(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_enable();
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void Cashindisable(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_disable();
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void Cashinreset(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_reset();
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void Cashinsetnotesaccept(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 3) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int cash_type = args[0].As<Number>()->Value();
	int accept = args[1].As<Number>()->Value(); 
	int finish = args[2].As<Number>()->Value(); 

	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_set_notes_accept(cash_type, accept, finish);
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void CashingetDatasetVersion(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_get_Dataset_Version();
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void CashingetFirmwareVersion(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_get_Firmware_Version();
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void CashinupgradeFirmwareProgram(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 2) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	stringstream ss1;
	v8::String::Utf8Value fileName(isolate, args[0]); 
	ss1 << *fileName;
	stringstream ss2;
	v8::String::Utf8Value arrPort(isolate, args[1]); 
	ss2 << *arrPort;

	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("cashin");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		json_out = g_cashin->cash_in_upgrade_Firmware_Program(ss1.str().c_str(), ss2.str().c_str());
	}
	else
	{
		root["result_code"] = -7;
		root["result_msg"] = "纸币接收器初始化失败";
		json_out = write.write(root);
	}

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
/*static void Unionconsume(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 11) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int apptype = args[0].As<Number>()->Value();
	int type = args[1].As<Number>()->Value();
	int money = args[2].As<Number>()->Value();
	int left = args[3].As<Number>()->Value();
	int top = args[4].As<Number>()->Value();
	int width = args[5].As<Number>()->Value();
	int height = args[6].As<Number>()->Value();
	int alpha = args[7].As<Number>()->Value();
	int r = args[8].As<Number>()->Value();
	int g = args[9].As<Number>()->Value();
	int b = args[10].As<Number>()->Value();
	
	string info = "";	
	//info = hd_union_consume(apptype, type, money, left, top, width, height, alpha, r, g, b);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Unionsettle(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_union_settle();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Unionsignin(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_union_signin();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Unioncancel(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_union_cancel();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/

/*static void ICcardsetKey(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	unsigned char keya_[16][6]={{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff}}; 
	unsigned char keyb_[16][6]={{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff},
							    {0xff, 0xff, 0xff, 0xff, 0xff, 0xff},{0xff, 0xff, 0xff, 0xff, 0xff, 0xff}}; 
	string info = "";
	//info = hd_ICcard_setKey((unsigned char**)keya_, (unsigned char**)keyb_);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
static void ICcarddisable(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}
	int blockNum = args[0].As<Number>()->Value();

	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("icCard");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		td->param->enable = false;
		td->param->blocknum = blockNum;
		root["result_code"] = 0;
		root["result_msg"] = "success";
		root["ICcard_error_code"] = 0;
		root["ICcard_error_msg"] = "RPD IC读卡器禁能成功！";
	}
	else
	{
		root["result_code"] = -39;
		root["result_msg"] = "RPD IC读卡器初始化失败";
		root["ICcard_error_code"] = -2;
		root["ICcard_error_msg"] = "RPD IC读卡器通讯失败";		
	}

	json_out = write.write(root);

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
static void ICcardenable(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}
	int blockNum = args[0].As<Number>()->Value();

	Json::Value root;
	Json::FastWriter write;	
	std::string json_out = "";
	
	map<string, ThreadData*>::iterator it = g_map_DevThreadData.find("icCard");
	if(it != g_map_DevThreadData.end())
	{
		ThreadData* td = it->second;
		td->param->enable = true;
		td->param->blocknum = blockNum;
		root["result_code"] = 0;
		root["result_msg"] = "success";
		root["ICcard_error_code"] = 0;
		root["ICcard_error_msg"] = "RPD IC读卡器使能成功！";
	}
	else
	{
		root["result_code"] = -39;
		root["result_msg"] = "RPD IC读卡器初始化失败";
		root["ICcard_error_code"] = -2;
		root["ICcard_error_msg"] = "RPD IC读卡器通讯失败";		
	}

	json_out = write.write(root);

	auto result = v8::String::NewFromUtf8(isolate, json_out.c_str(), v8::NewStringType::kNormal, (int)json_out.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}
/*static void ICcardsearchCard(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int type = args[0].As<Number>()->Value();

	string info = "";
	//info = hd_ICcard_searchCard(type);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcardreadCard(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_ICcard_readCard();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcardreadBlock(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	if (!args[0]->IsNumber()) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int blocknum = args[0].As<Number>()->Value();

	string info = "";
	//info = hd_ICcard_readBlock(blocknum);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcardwriteBlock(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 3) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int blocknum = args[0].As<Number>()->Value();
	v8::String::Utf8Value toWriteBuf(isolate, args[1]); 
	stringstream ss;
	ss << *toWriteBuf;
	int size = args[2].As<Number>()->Value();
	
	string info = "";
	//info = hd_ICcard_writeBlock(blocknum, (unsigned char *)ss.str().c_str(), size);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcardinitWallet(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 2) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int blocknum = args[0].As<Number>()->Value();
	int money = args[1].As<Number>()->Value();
	
	string info = "";
	//info = hd_ICcard_initWallet(blocknum, money);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcardreadBalance(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int blocknum = args[0].As<Number>()->Value();
	
	string info = "";
	//info = hd_ICcard_readBalance(blocknum);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcardrechargeWallet(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 2) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int blocknum = args[0].As<Number>()->Value();
	int money = args[1].As<Number>()->Value();
	
	string info = "";
	//info = hd_ICcard_rechargeWallet(blocknum, money);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void ICcarddeductWallet(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 2) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int blocknum = args[0].As<Number>()->Value();
	int money = args[1].As<Number>()->Value();
	
	string info = "";
	//info = hd_ICcard_deductWallet(blocknum, money);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/

/*static void TestJson(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_test_json();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Cashoutcheck(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_cash_out_check();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Cashoutreset(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";
	//info = hd_cash_out_reset();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Cashoutpayout(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 1) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int money = args[0].As<Number>()->Value();
	
	string info = "";	
	//info = hd_cash_out_payout(money);
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Ecardconsume(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	if (args.Length() < 11) {
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, "参数数量错误", NewStringType::kNormal).ToLocalChecked()));
		return;
	}

	int mny = args[0].As<Number>()->Value();
	int i_left = args[1].As<Number>()->Value();
	int i_top = args[2].As<Number>()->Value();
	int i_width = args[3].As<Number>()->Value();
	int i_height = args[4].As<Number>()->Value();
	int i_alpha = args[5].As<Number>()->Value();
	int i_r = args[6].As<Number>()->Value();
	int i_g = args[7].As<Number>()->Value();
	int i_b = args[8].As<Number>()->Value();
	int overtimes = args[9].As<Number>()->Value();
	v8::String::Utf8Value i_reserve1(isolate, args[10]); 
	stringstream ss;
	ss << *i_reserve1;

	string info = "";	
	//info = hd_ecard_consume(mny,i_left,i_top,i_width,i_height,i_alpha,i_r,i_g,i_b,overtimes,(char*)ss.str().c_str());
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Ecardsignin(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";	
	//info = hd_ecard_sign_in();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/
/*static void Ecardsettleaccount(const FunctionCallbackInfo<Value>& args) 
{
	Isolate* isolate = args.GetIsolate();
	Local<Context> context = isolate->GetCurrentContext(); 
	
	string info = "";	
	//info = hd_ecard_settle_account();
	auto result = v8::String::NewFromUtf8(isolate, info.c_str(), v8::NewStringType::kNormal, (int)info.size()).ToLocalChecked();
	args.GetReturnValue().Set(result);
}*/




  
void Init(Local<Object> exports, Local<Object> module) {  
  NODE_SET_METHOD(exports, "add", Add);
  //NODE_SET_METHOD(module, "exports", RunCallback);
  NODE_SET_METHOD(exports, "runCallback", RunCallback);
  NODE_SET_METHOD(exports, "runCallback2", RunCallback2);
  NODE_SET_METHOD(exports, "hdhardwareinit", HardWareInit);
  NODE_SET_METHOD(exports, "hdhardwareend", HardWareEnd);
  
  /*NODE_SET_METHOD(exports, "hdcoininenable", CoinInEnable);
  NODE_SET_METHOD(exports, "hdcoinindisable", CoinInDisable);
  NODE_SET_METHOD(exports, "hdcoinoutcheck", CoinOutCheck);
  NODE_SET_METHOD(exports, "hdcoinoutreset", CoinOutReset);
  NODE_SET_METHOD(exports, "hdcoinoutpayout", CoinOutPayout);
  NODE_SET_METHOD(exports, "hdcoinoutpayoutbynum", CoinOutPayoutByNum);
  NODE_SET_METHOD(exports, "hdcoinoutpayoutbynum3", CoinOutPayoutByNum3);
  NODE_SET_METHOD(exports, "hdcoinoutclear", CoinOutClear);

  NODE_SET_METHOD(exports, "hdgoodsout", GoodsOut);
  NODE_SET_METHOD(exports, "hdgoodstest", GoodsTest);*/

  NODE_SET_METHOD(exports, "hdprinterecho", PrinterEcho);
  NODE_SET_METHOD(exports, "hdprintercut", PrinterCut);
  /*NODE_SET_METHOD(exports, "hdprinterecho12", PrinterEcho12);
  NODE_SET_METHOD(exports, "hdprinterecho2", PrinterEcho2);
  NODE_SET_METHOD(exports, "hdprinterecho22", PrinterEcho22);
  NODE_SET_METHOD(exports, "hdprintercheckstatus", PrinterCheckStatus);
  NODE_SET_METHOD(exports, "hdprinterfastpic", PrinterFastPic);*/

  NODE_SET_METHOD(exports, "hdcashinenable", Cashinenable);
  NODE_SET_METHOD(exports, "hdcashindisable", Cashindisable);
  NODE_SET_METHOD(exports, "hdcashinsetnotesaccept", Cashinsetnotesaccept);
  NODE_SET_METHOD(exports, "hdcashinreset", Cashinreset);
  NODE_SET_METHOD(exports, "hdcashingetDatasetVersion", CashingetDatasetVersion);
  NODE_SET_METHOD(exports, "hdcashingetFirmwareVersion", CashingetFirmwareVersion);
  NODE_SET_METHOD(exports, "hdcashinupgradeFirmwareProgram", CashinupgradeFirmwareProgram);

  /*NODE_SET_METHOD(exports, "hdunionconsume", Unionconsume);
  NODE_SET_METHOD(exports, "hdunionsettle", Unionsettle);
  NODE_SET_METHOD(exports, "hdunionsignin", Unionsignin);
  NODE_SET_METHOD(exports, "hdunioncancel", Unioncancel);
  
  NODE_SET_METHOD(exports, "hdICcardsetKey", ICcardsetKey);*/
  NODE_SET_METHOD(exports, "hdICcardenable", ICcardenable);
  NODE_SET_METHOD(exports, "hdICcarddisable", ICcarddisable);
  /*NODE_SET_METHOD(exports, "hdICcardsearchCard", ICcardsearchCard);
  NODE_SET_METHOD(exports, "hdICcardreadCard", ICcardreadCard);
  NODE_SET_METHOD(exports, "hdICcardreadBlock", ICcardreadBlock);
  NODE_SET_METHOD(exports, "hdICcardwriteBlock", ICcardwriteBlock);
  NODE_SET_METHOD(exports, "hdICcardinitWallet", ICcardinitWallet);
  NODE_SET_METHOD(exports, "hdICcardreadBalance", ICcardreadBalance);
  NODE_SET_METHOD(exports, "hdICcardrechargeWallet", ICcardrechargeWallet);
  NODE_SET_METHOD(exports, "hdICcarddeductWallet", ICcarddeductWallet);

  NODE_SET_METHOD(exports, "hdtestjson", TestJson);

  NODE_SET_METHOD(exports, "hdcashoutcheck", Cashoutcheck);
  NODE_SET_METHOD(exports, "hdcashoutreset", Cashoutreset);
  NODE_SET_METHOD(exports, "hdcashoutpayout", Cashoutpayout);

  NODE_SET_METHOD(exports, "hdecardconsume", Ecardconsume);
  NODE_SET_METHOD(exports, "hdecardsignin", Ecardsignin);
  NODE_SET_METHOD(exports, "hdecardsettleaccount", Ecardsettleaccount);*/
}

NODE_MODULE(NODE_GYP_MODULE_NAME, Init)