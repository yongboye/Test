﻿#ifndef TOOLS_H_
#define TOOLS_H_

#include <string.h>
#include <iostream>
using namespace std;


//#define _YYB_DEBUG
#ifdef _YYB_DEBUG
#define debug(...) {printf("[debug]  "); printf(__VA_ARGS__);}
#else
#define debug(...)
#endif


enum WarnOption{
	WO_SAVE2FILE		= 1,
	WO_MSG_SYS			= 2,
	WO_MSG_CASHIN		= 4,
	WO_MSG_CASHOUT		= 8,
	WO_MSG_CASHOUTTEN	= 16,
	WO_MSG_COININ		= 32,
	WO_MSG_COINOUTHALF	= 64,
	WO_MSG_COINOUTONE	= 128,
	WO_MSG_DB			= 256
};


/*int write_log(char*data,...);
#define warn(...) \
	do{\
	std::string temp;\
	char buf[40960] = {0};\
	sprintf(buf, __VA_ARGS__);\
	temp += buf;\
	temp += "          ";\
	temp += "{";\
	temp += __FUNCTION__;\
	temp += "}";\
	write_log("%s", temp.c_str());\
	}while(0)*/

#define MINFUNCTION(a, b) (a>b ? b : a)


string put_out_hex(unsigned char *data, int len);
#define hex_str(data, len)	(put_out_hex((unsigned char *)data, len).c_str())


string get_EachModule_Initinfo(int err_code);
string get_CoinModule_Inifinfo(int code);
string getEcardCodeInfo(int ret, unsigned char code);
#endif

